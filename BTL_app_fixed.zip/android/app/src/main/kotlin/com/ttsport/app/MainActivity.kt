package com.ttsport.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
